#encoding: utf-8

MYSQL_HOST = 'localhost'
MYSQL_PORT = 3306
MYSQL_USER = 'root'
MYSQL_PASSWD = 'pip123'
MYSQL_DB = 'cmdb'
MYSQL_CHARSET = 'utf8'
